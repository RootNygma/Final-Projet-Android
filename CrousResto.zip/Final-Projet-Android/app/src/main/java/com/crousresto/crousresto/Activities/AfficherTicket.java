package com.crousresto.crousresto.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.crousresto.crousresto.R;

public class AfficherTicket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afficher_ticket);
    }
}
